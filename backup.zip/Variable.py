# Variables are reserved memory locations to store values. 


# declcare a variabe var and assign it a value.

var = 100
print("The value of var is "+str(var))


#Re-declaring the variable var.

var = "Welcome"
print(var)