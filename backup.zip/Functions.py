# A function is a block of organized, reusable code that is used to perform a single, related action.

# Define a function.
def fun():
    print("What's a Funtion ?")
     

# Functions with Arguments.

def funArg(arg1,arg2):
    print(arg1," ",arg2)
  #  return(arg1," ",arg2)
    
    
 #Functions that returns a value
def funX(a):
    return a+a

        
# Calling the Function.        
fun()

funArg(50,50)

print(funArg(50,50))

print(funX(50))

