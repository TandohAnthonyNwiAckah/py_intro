# About Information.

name = input("What is your name?") 

print("Your name is: ",  name)

age = input("How old are you?")

print("You are " + age + " years old.")



