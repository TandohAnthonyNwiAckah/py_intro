# Introduction to python.
# Python is an interpreted high-level programming language for general-purpose programming. 
# It was created by Guido van Rossum and first released in 1991.

# Colon appears at the start of a new Block.
# Use a new Line to end a line of code.

def main():
     print("Hello World")


if __name__ == "__main__":
     main()
